If windows points out that newer utilities exist on your computer, choose the option to keep the existing functions. It is best to download the visual basic 6 runtime libraries from the microsoft website and just use the executive files provided without installation. To view the source codes provided it is good to have VB6 installed on your computer, if you can't then use a test editor to read the frm extentions files.

To download the vb6 runtime go to the following website.

http://support.microsoft.com/kb/192461

If you have VB6 runtime already on your computer, you can run the exe files in any folder, but you must make sure that the support files are also in the folder.

hx19v2access requires

port.txt (this file has the port number of the hx19ms usb or serial synchronizer).


hx19v2xyzDDE and hx19v2xyzLabDDE require

dataFiles		this is a folder or (directory), it can be empty (create this folder)
hx19xyzDDE.txt		the first line in this file must contain the hx19ms usb port number
map.txt			this file is required to let the program know where the receivers are

