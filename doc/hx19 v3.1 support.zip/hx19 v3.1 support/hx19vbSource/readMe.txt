There are two programs here used to determine the xyz coordinates of n number of tags, one uses time difference of flight and iterates using a least square method to find the xyz. The other triangulates assuming that there is a 90 degree angle between all the receivers measuring the distance.

The former is hx19xyzDDEi and the latter is hx19xyzDDE_lab

Hx19xyzDDE_lab likes the following receiver formation

40 41
42 43

X is horizontal and Y is vertical here. Go to www.hexamite.com/hx19posb.htm

